import styled from "styled-components";

const Header = styled.header`
  padding: 2em;
  border: 1px solid #dfdfdf;
`;

export default Header;
