import styled from "styled-components";
const Message = styled.span`
  margin-bottom: 0.5em;
  color: palevioletred;
  display: block;
  position: absolute;
`;
export default Message;
