import styled from "styled-components";
const Input = styled.input`
  padding: 0.5em;
  color: palevioletred;
  background: papayawhip;
  border: none;
  border-radius: 3px;
  width: 100%;
  margin-bottom: 0.5em;
  cursor: ${(props) => props.cursor ?? "auto"};
  position: relative;
`;
export default Input;
