import React from "react";
import { getTimezoneOffset } from "../../utils/utils";
import Item from "../UI/Grid/Item";

const Clock = ({
  handleDeleteClock,
  handleEditClock,
  value,
  second,
  item: { id, clockName, event, eventTime, zone, zoneTime },
}) => {
  //console.log(item);
  return (
    <Item>
      <h2> Clcok Name: {zone.split("/")[1]}</h2>
      <span>
        Time:
        {new Date(second).toLocaleTimeString("en-US", {
          timeZone: zone,
        })}
      </span>
      <span>Time zone: {zone}</span>
      <span>{getTimezoneOffset(zone, new Date(2016, 0, 1))}</span>
      <span>Event Name: {event}</span>
      <span>Event Time: {eventTime}</span>
      <button onClick={() => handleEditClock(value)}>Edit</button>
      <button onClick={() => handleDeleteClock(id)}>Delete</button>
    </Item>
  );
};

export default Clock;

/**
 * clockName: "name"
event: "Evenet Nmaehhhh"
eventTime: "03:46"
id: 0
zone: "Europe/Tirane"
zoneTime: "vvvv"
 */
