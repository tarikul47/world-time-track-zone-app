/**
 * GMT Find Out
 */
const getTimezoneOffset = (tz, hereDate) => {
  hereDate = new Date(hereDate || Date.now());
  hereDate.setMilliseconds(0); // for nice rounding

  const hereOffsetHrs = (hereDate.getTimezoneOffset() / 60) * -1,
    thereLocaleStr = hereDate.toLocaleString("en-US", { timeZone: tz }),
    thereDate = new Date(thereLocaleStr),
    diffHrs = (thereDate.getTime() - hereDate.getTime()) / 1000 / 60 / 60,
    thereOffsetHrs = hereOffsetHrs + diffHrs;

  console.log(
    tz,
    thereDate,
    "UTC" + (thereOffsetHrs < 0 ? "" : "+") + thereOffsetHrs
  );
  return "GMT" + (thereOffsetHrs < 0 ? "" : "+") + thereOffsetHrs;
};

/**
 * unique id generator
 */
 function* generateId() {
  var id = 0;
  while (true) {
    yield id++;
  }
}
const guid = generateId();

/**
 * Initial values for clock
 */
const intialvalues = {
  zone: "",
  event: "",
  eventTime: "",
};


export { getTimezoneOffset, intialvalues, guid };
